package com.kh.practice;

public class ValueLengthException extends Exception {

	public ValueLengthException() {}
	public ValueLengthException(String msg) {
		super(msg);
	}
}
