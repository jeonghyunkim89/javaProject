package com.kh.practice.token.run;

import com.kh.practice.token.view.TokenMenu;

public class Run {

	public static void main(String[] args) {
		//TokenMenu 객체의 메소	드를 불러옴
		TokenMenu tm = new TokenMenu();
		tm.mainMenu();
	}

}
