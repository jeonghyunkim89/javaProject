package com.kh.practice.set.run;

import com.kh.practice.set.view.LotteryMenu;

public class Run {

	public static void main(String[] args) {

		LotteryMenu lm = new LotteryMenu();
		lm.mainMenu();
	}

}
