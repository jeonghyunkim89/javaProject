package com.kh.ch13_generics;

public class Box<T> {
	
	private T[] list;
	private int size;
	
	public Box() {}
	public Box(T[] list, int size) {}
	
	

}
