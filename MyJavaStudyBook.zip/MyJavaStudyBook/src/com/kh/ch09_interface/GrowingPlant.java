package com.kh.ch09_interface;

public interface GrowingPlant {
	
	/*public abstract*/void sprinkleWater();
	/*public abstract*/void baskSun();

}
