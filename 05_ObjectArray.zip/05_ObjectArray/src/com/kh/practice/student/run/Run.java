package com.kh.practice.student.run;

public class Run {

	public static void main(String[] args) {

		StudentMenu sm = new StudentMenu();
		
	}

}
