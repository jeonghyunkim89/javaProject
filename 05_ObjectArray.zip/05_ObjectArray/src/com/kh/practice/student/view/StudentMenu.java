package com.kh.practice.student.view;

import com.kh.practice.student.controller.StudentController;

public class StudentMenu {
	
	private StudentController ssm = new StudentController();
	
	public StudentMenu() {
		//학생정보와 성적, 결과 출력하는 기본생성자
		ssm.printStudent();
		ssm.avgScore();
		if(ssm.avgScore()<ssm.CUT_LINE) {
		System.out.println("재시험 대상");
		} else {
			System.out.println("통과");
		}
	}
}
