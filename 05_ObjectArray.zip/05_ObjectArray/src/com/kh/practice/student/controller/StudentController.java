package com.kh.practice.student.controller;

import com.kh.practice.student.model.vo.Student;

public class StudentController {
	//5개의 객체배열을 위의 샘플 데이터의 값으로 초기화 해주는 기본 생성자 
	private Student[] sArr = new Student[5];
	public static final int CUT_LINE = 60;
	
	public StudentController() {
		sArr[0]= {김길동, 자바, 100};
		// sArr[0] ---> Student s0 = new Student("김길동", "자바", 100);
		sArr[1]= {박길동, 디비, 50};
		sArr[2]= {이길동, 화면, 85};
	}
	public Student[] printStudent() {
		//객체 배열에 있는 데이터 반환
		return sArr;
	}
	public int sumScore() {
		return 1;
	}
	public double avgScore() {
		return 0.00;
	}
}
