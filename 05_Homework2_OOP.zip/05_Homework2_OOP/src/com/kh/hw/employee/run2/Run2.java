package com.kh.hw.employee.run2;

import com.kh.hw.employee.view2.EmployeeMenu2;

public class Run2 {

	public static void main(String[] args) {

		EmployeeMenu2 em = new EmployeeMenu2();
	}

}
