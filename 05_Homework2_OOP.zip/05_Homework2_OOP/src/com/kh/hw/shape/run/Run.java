package com.kh.hw.shape.run;

import com.kh.hw.shape.view.ShapeMenu;

public class Run {

	public static void main(String[] args) {
		// ShapeMenu 객체를 생성한 후 inputMenu()실행
		ShapeMenu sm = new ShapeMenu();
		//호출방법은 생성자 변수명.불러올 메소드명
		sm.inputMenu();
		
		
	}

}
